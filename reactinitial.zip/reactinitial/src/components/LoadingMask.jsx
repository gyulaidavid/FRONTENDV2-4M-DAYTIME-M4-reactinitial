import React, {useEffect, useState} from 'react'
import { Dots } from 'loading-animations-react';

function LoadingMask() {

//     const [loadingAnim, setLoadingAnim] = useState(false);

// useEffect(() => {
//     setTimeout(() => setLoadingAnim(true), 5000);
// }, []);

  return (
    <div>
        
   <Dots /> 

    </div>
  )
}

export default LoadingMask